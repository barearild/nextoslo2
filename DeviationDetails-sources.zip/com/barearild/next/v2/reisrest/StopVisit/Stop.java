
package com.barearild.next.v2.reisrest.StopVisit;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class Stop {

    @SerializedName("stopID")
    @Expose
    private Integer stopID;
    @SerializedName("stopName")
    @Expose
    private String stopName;

    /**
     * 
     * @return
     *     The stopID
     */
    public Integer getStopID() {
        return stopID;
    }

    /**
     * 
     * @param stopID
     *     The stopID
     */
    public void setStopID(Integer stopID) {
        this.stopID = stopID;
    }

    /**
     * 
     * @return
     *     The stopName
     */
    public String getStopName() {
        return stopName;
    }

    /**
     * 
     * @param stopName
     *     The stopName
     */
    public void setStopName(String stopName) {
        this.stopName = stopName;
    }

}
