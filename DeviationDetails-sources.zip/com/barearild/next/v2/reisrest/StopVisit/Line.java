
package com.barearild.next.v2.reisrest.StopVisit;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class Line {

    @SerializedName("lineID")
    @Expose
    private Integer lineID;
    @SerializedName("lineName")
    @Expose
    private String lineName;
    @SerializedName("transportationTypeID")
    @Expose
    private Integer transportationTypeID;

    /**
     * 
     * @return
     *     The lineID
     */
    public Integer getLineID() {
        return lineID;
    }

    /**
     * 
     * @param lineID
     *     The lineID
     */
    public void setLineID(Integer lineID) {
        this.lineID = lineID;
    }

    /**
     * 
     * @return
     *     The lineName
     */
    public String getLineName() {
        return lineName;
    }

    /**
     * 
     * @param lineName
     *     The lineName
     */
    public void setLineName(String lineName) {
        this.lineName = lineName;
    }

    /**
     * 
     * @return
     *     The transportationTypeID
     */
    public Integer getTransportationTypeID() {
        return transportationTypeID;
    }

    /**
     * 
     * @param transportationTypeID
     *     The transportationTypeID
     */
    public void setTransportationTypeID(Integer transportationTypeID) {
        this.transportationTypeID = transportationTypeID;
    }

}
